import { Calendar, MapPin, Users, Award, Building2, Heart, X, ExternalLink, Mail } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import type { Event } from '../types';

interface EventModalProps {
  event: Event;
  isFavorite: boolean;
  onToggleFavorite: (eventId: string) => void;
  onClose: () => void;
}

const typeLabels: Record<Event['type'], string> = {
  olympiad: 'Олимпиада',
  competition: 'Конкурс',
  startup: 'Стартап',
  program: 'Программа'
};

const typeColors: Record<Event['type'], string> = {
  olympiad: 'bg-purple-100 text-purple-800',
  competition: 'bg-blue-100 text-blue-800',
  startup: 'bg-green-100 text-green-800',
  program: 'bg-orange-100 text-orange-800'
};

export function EventModal({ event, isFavorite, onToggleFavorite, onClose }: EventModalProps) {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <Badge className={typeColors[event.type]}>
                {typeLabels[event.type]}
              </Badge>
              <DialogTitle className="text-2xl mt-2">{event.title}</DialogTitle>
            </div>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => onToggleFavorite(event.id)}
            >
              <Heart
                className={`w-5 h-5 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
              />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          <img
            src={event.imageUrl}
            alt={event.title}
            className="w-full h-64 object-cover rounded-lg"
          />

          <div>
            <h3 className="text-sm text-gray-500 mb-2">Описание</h3>
            <p className="text-gray-700 leading-relaxed">{event.description}</p>
          </div>

          <Separator />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Building2 className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-500">Организатор</p>
                  <p className="text-gray-900">{event.organizer}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-500">Дедлайн регистрации</p>
                  <p className="text-gray-900">
                    {new Date(event.deadline).toLocaleDateString('ru-RU', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Calendar className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-500">Даты проведения</p>
                  <p className="text-gray-900">
                    {new Date(event.startDate).toLocaleDateString('ru-RU', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                    {event.endDate && ` - ${new Date(event.endDate).toLocaleDateString('ru-RU', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}`}
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-500">Место проведения</p>
                  <p className="text-gray-900">{event.location}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Users className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-500">Возрастная группа</p>
                  <p className="text-gray-900">{event.ageGroup}</p>
                </div>
              </div>

              {event.prize && (
                <div className="flex items-start gap-3">
                  <Award className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-500">Призы</p>
                    <p className="text-gray-900">{event.prize}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm text-gray-500 mb-3">Теги</h3>
            <div className="flex flex-wrap gap-2">
              {event.tags.map((tag, index) => (
                <Badge key={index} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          <Separator />

          {/* Ресурсы для подготовки */}
          {event.resources && event.resources.length > 0 && (
            <>
              <div>
                <h3 className="text-sm text-gray-500 mb-3">Ресурсы для подготовки</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {event.resources.map((resource, index) => (
                    <a
                      key={index}
                      href={resource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 p-3 border rounded-lg hover:bg-gray-50 transition-colors text-blue-600 hover:text-blue-800"
                    >
                      <ExternalLink className="w-4 h-4 flex-shrink-0" />
                      <span className="text-sm">{resource.name}</span>
                    </a>
                  ))}
                </div>
              </div>

              <Separator />
            </>
          )}

          {!event.registrationOpen && (
            <div className="bg-gray-100 border border-gray-200 rounded-lg p-4">
              <p className="text-sm text-gray-700">
                <strong>Регистрация закрыта.</strong> Следите за анонсами новых мероприятий.
              </p>
            </div>
          )}

          <div className="flex gap-3">
            {event.registrationOpen && (
              <Button
                className="flex-1"
                size="lg"
                asChild
              >
                <a href={`mailto:registration@edux.kz?subject=Регистрация на ${event.title}&body=Здравствуйте! Хочу зарегистрироваться на мероприятие: ${event.title}`}>
                  <Mail className="w-4 h-4 mr-2" />
                  Регистрация через email
                </a>
              </Button>
            )}
            <Button
              variant={event.registrationOpen ? "outline" : "default"}
              size="lg"
              disabled={!event.registrationOpen}
              asChild={event.registrationOpen}
              className={event.registrationOpen ? "" : "flex-1"}
            >
              {event.registrationOpen ? (
                <a href={event.website} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Сайт
                </a>
              ) : (
                <>Регистрация закрыта</>
              )}
            </Button>
            <Button variant="outline" size="lg" onClick={onClose}>
              Закрыть
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}