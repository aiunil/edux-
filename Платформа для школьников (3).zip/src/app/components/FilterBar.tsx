import { Search } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import type { EventType } from '../types';

interface FilterBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedType: EventType | 'all';
  onTypeChange: (type: EventType | 'all') => void;
}

const eventTypes = [
  { value: 'all' as const, label: 'Все' },
  { value: 'olympiad' as const, label: 'Олимпиады' },
  { value: 'competition' as const, label: 'Конкурсы' },
  { value: 'startup' as const, label: 'Стартапы' },
  { value: 'program' as const, label: 'Программы' }
];

export function FilterBar({ searchQuery, onSearchChange, selectedType, onTypeChange }: FilterBarProps) {
  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <Input
          type="text"
          placeholder="Найти олимпиаду, конкурс, хакатон..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {eventTypes.map((type) => (
          <Button
            key={type.value}
            variant={selectedType === type.value ? 'default' : 'outline'}
            onClick={() => onTypeChange(type.value)}
            size="sm"
          >
            {type.label}
          </Button>
        ))}
      </div>
    </div>
  );
}