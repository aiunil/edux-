interface Category {
  id: string;
  emoji: string;
  label: string;
  tags: string[];
}

const categories: Category[] = [
  {
    id: 'informatics',
    emoji: '💻',
    label: 'ИВТ / Информатика',
    tags: ['ИВТ', 'Информатика', 'Программирование']
  },
  {
    id: 'math',
    emoji: '📐',
    label: 'Математика',
    tags: ['Математика']
  },
  {
    id: 'physics',
    emoji: '⚛️',
    label: 'Физика',
    tags: ['Физика']
  },
  {
    id: 'geography',
    emoji: '🌍',
    label: 'География',
    tags: ['География']
  },
  {
    id: 'economics',
    emoji: '💼',
    label: 'Экономика',
    tags: ['Экономика']
  },
  {
    id: 'law',
    emoji: '⚖️',
    label: 'Право и МО',
    tags: ['Право', 'МО']
  },
  {
    id: 'space',
    emoji: '🚀',
    label: 'Космос',
    tags: ['Космос', 'Астрономия']
  },
  {
    id: 'english',
    emoji: '🇬🇧',
    label: 'Английский язык',
    tags: ['Английский']
  }
];

interface CategoryGridProps {
  onCategoryClick: (tags: string[]) => void;
  selectedCategory: string | null;
}

export function CategoryGrid({ onCategoryClick, selectedCategory }: CategoryGridProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onCategoryClick(category.tags)}
          className={`
            flex flex-col items-center justify-center gap-2 p-4 rounded-xl border-2 
            transition-all hover:shadow-md hover:scale-105 active:scale-95
            ${selectedCategory === category.id 
              ? 'border-blue-500 bg-blue-50 shadow-md' 
              : 'border-gray-200 bg-white hover:border-blue-300'
            }
          `}
        >
          <span className="text-3xl">{category.emoji}</span>
          <span className="text-sm text-center text-gray-700">
            {category.label}
          </span>
        </button>
      ))}
    </div>
  );
}